package com.example.dogwalker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Calendar;

/*
* Justin Van Loo
* ISYS 221
* Hira Herrington
* Assignment 3
*
* The purpose of this app is to let someone select the number of dogs and the
* date that they want their dogs to be walked on.
*
* inputs
* user selects the number of dogs to be walked
* user also selects the date for dogs to be walked on
*
* outputs
* confirmation to the screen of the date and number of dogs to be walked, as well as
* the price
*
* 
* */

public class MainActivity extends AppCompatActivity {
    private TextView reservation;
    String msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        reservation = (TextView) findViewById(R.id.txtreservation);
        Button button = (Button) findViewById(R.id.button);



        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainActivity.this, d, c.get(Calendar.YEAR), c.get(Calendar.MONTH),
                        c.get(Calendar.DAY_OF_MONTH)).show();
            }

        });
    }

    Calendar c = Calendar.getInstance();
    DateFormat fmtDate = DateFormat.getDateInstance();
    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

            RadioButton radio1 = (RadioButton) findViewById(R.id.radioButton);
            RadioButton radio2 = (RadioButton) findViewById(R.id.radioButton2);
            RadioButton radio3 = (RadioButton) findViewById(R.id.radioButton3);
            RadioButton radio4 = (RadioButton) findViewById(R.id.radioButton4);

            if (radio1.isChecked()){
                msg = "You have selected to walk one dog for the price of $15 with ";
            }
            else if (radio2.isChecked()){
                msg = "You have selected to walk two dogs for the price of $30 with ";
            }
            else if (radio3.isChecked()){
                msg = "You have selected to walk three dogs for the price of $45 with ";
            }
            else if (radio4.isChecked()){
                msg = "You have selected to walk four dogs for the price of $60 with ";
            }
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            reservation.setText(msg + "your reservation set for " + fmtDate.format(c.getTime()));

        }
    };

}
