package com.example.animation;

/**
 * Justin Van Loo
 * ISYS 221
 * Hira Herrington
 * 11/19/2019
 *
 * This Program runs a frame animation as well as a tween animation, When you
 * Push the buttons.
 *
 *
 */



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable assassinAnimation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imgFrame = findViewById(R.id.imageassassin);
        imgFrame.setBackgroundResource(R.drawable.animation);
        assassinAnimation = (AnimationDrawable)imgFrame.getBackground();
    }

    public void onClickTween(View view) {
        assassinAnimation.stop();
        startActivity(new Intent(this, tween.class));
    }

    public void onClickframe(View view) {
        assassinAnimation.start();
    }
}
